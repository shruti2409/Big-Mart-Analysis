# Big-Mart-sales-prediction
Please find the link of deployment here-     https://big-mart-sale-predict.herokuapp.com/predict
